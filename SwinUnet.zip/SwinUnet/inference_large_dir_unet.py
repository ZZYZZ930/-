from osgeo import gdal
import numpy as np
import argparse
import math
import torch
from networks.unet import UNet as ViT_seg

from config import get_config
import os
os.environ["OPENCV_IO_MAX_IMAGE_PIXELS"] = pow(2,40).__str__()
from torchvision import transforms as T

parser = argparse.ArgumentParser()
parser.add_argument('--output_dir', default="./output_unet" ,type=str, help='output dir')
parser.add_argument('--batch_size', type=int, default=1,
                    help='batch_size per gpu')
parser.add_argument('--num_classes', type=int,
                    default=22, help='output channel of network')

parser.add_argument('--img_size', type=int,
                    default=512, help='input patch size of network input')
parser.add_argument('--cfg', type=str, default="configs/swin_tiny_patch4_window7_224_lite.yaml", metavar="FILE", help='path to config file', )
parser.add_argument(
        "--opts",
        help="Modify config options by adding 'KEY VALUE' pairs. ",
        default=None,
        nargs='+',
    )
parser.add_argument('--zip', action='store_true', help='use zipped dataset instead of folder dataset')
parser.add_argument('--cache-mode', type=str, default='part', choices=['no', 'full', 'part'],
                    help='no: no cache, '
                            'full: cache all data, '
                            'part: sharding the dataset into nonoverlapping pieces and only cache one piece')
parser.add_argument('--accumulation-steps', type=int, help="gradient accumulation steps")
parser.add_argument('--use-checkpoint', action='store_true',
                    help="whether to use gradient checkpointing to save memory")
parser.add_argument('--amp-opt-level', type=str, default='O1', choices=['O0', 'O1', 'O2'],
                    help='mixed precision opt level, if O0, no amp is used')
parser.add_argument('--resume', help='resume from checkpoint')
parser.add_argument('--tag', help='tag of experiment')
parser.add_argument('--throughput', action='store_true', help='Test throughput only')

parser.add_argument('--eval', action='store_true', help='Perform evaluation only')
args = parser.parse_args()
# if args.dataset == "Synapse":
#     args.volume_path = os.path.join(args.volume_path, "test_vol_h5")
config = get_config(args)

window_size = args.img_size   #***************************** 224/512
# 读取tif数据集
def readTif(fileName, xoff=0, yoff=0, data_width=0, data_height=0):
    dataset = gdal.Open(fileName)
    if dataset == None:
        print(fileName + "文件无法打开")
    #  栅格矩阵的列数
    width = dataset.RasterXSize
    #  栅格矩阵的行数
    height = dataset.RasterYSize
    #  获取数据
    if (data_width == 0 and data_height == 0):
        data_width = width
        data_height = height
    data = dataset.ReadAsArray(xoff, yoff, data_width, data_height)
    transform = dataset.GetGeoTransform()
    proj = dataset.GetProjection()

    return data,transform,proj


# 保存tif文件函数
def writeTiff(fileName, data, im_geotrans=(0, 0, 0, 0, 0, 0), im_proj=""):
    if 'int8' in data.dtype.name:
        datatype = gdal.GDT_Byte
    elif 'int16' in data.dtype.name:
        datatype = gdal.GDT_UInt16
    else:
        datatype = gdal.GDT_Float32
    if len(data.shape) == 3:
        im_bands, im_height, im_width = data.shape
    elif len(data.shape) == 2:
        data = np.array([data])
        im_bands, im_height, im_width = data.shape

    # 创建文件
    driver = gdal.GetDriverByName("GTiff")
    dataset = driver.Create(fileName, int(im_width), int(im_height), int(im_bands), datatype)
    if (dataset != None):
        dataset.SetGeoTransform(im_geotrans)  # 写入仿射变换参数
        dataset.SetProjection(im_proj)  # 写入投影
    for i in range(im_bands):
        dataset.GetRasterBand(i + 1).WriteArray(data[i])
    del dataset


#  tif裁剪（tif像素数据，裁剪边长）
def TifCroppingArray(img, SideLength):
    #  裁剪链表
    TifArrayReturn = []
    #  列上图像块数目
    ColumnNum = int((img.shape[0] - SideLength * 2) / (window_size - SideLength * 2))
    #  行上图像块数目
    RowNum = int((img.shape[1] - SideLength * 2) / (window_size - SideLength * 2))
    for i in range(ColumnNum):
        TifArray = []
        for j in range(RowNum):
            cropped = img[i * (window_size - SideLength * 2): i * (window_size - SideLength * 2) + window_size,
                      j * (window_size - SideLength * 2): j * (window_size - SideLength * 2) + window_size]
            TifArray.append(cropped)
        TifArrayReturn.append(TifArray)
    #  考虑到行列会有剩余的情况，向前裁剪一行和一列
    #  向前裁剪最后一列
    for i in range(ColumnNum):
        cropped = img[i * (window_size - SideLength * 2): i * (window_size - SideLength * 2) + window_size,
                  (img.shape[1] - window_size): img.shape[1]]
        TifArrayReturn[i].append(cropped)
    #  向前裁剪最后一行
    TifArray = []
    for j in range(RowNum):
        cropped = img[(img.shape[0] - window_size): img.shape[0],
                  j * (window_size - SideLength * 2): j * (window_size - SideLength * 2) + window_size]
        TifArray.append(cropped)
    #  向前裁剪右下角
    cropped = img[(img.shape[0] - window_size): img.shape[0],
              (img.shape[1] - window_size): img.shape[1]]
    TifArray.append(cropped)
    TifArrayReturn.append(TifArray)
    #  列上的剩余数
    ColumnOver = (img.shape[0] - SideLength * 2) % (window_size - SideLength * 2) + SideLength
    #  行上的剩余数
    RowOver = (img.shape[1] - SideLength * 2) % (window_size - SideLength * 2) + SideLength
    return TifArrayReturn, RowOver, ColumnOver


#  获得结果矩阵
def Result(shape, TifArray, npyfile, RepetitiveLength, RowOver, ColumnOver):
    result = np.zeros(shape, np.uint8)
    #  j来标记行数
    j = 0
    # print("***********line: ",j,"*****************")
    for i, img in enumerate(npyfile):
        #  最左侧一列特殊考虑，左边的边缘要拼接进去
        if (i % len(TifArray[0]) == 0):
            #  第一行的要再特殊考虑，上边的边缘要考虑进去
            if (j == 0):
                result[0: window_size - RepetitiveLength, 0: window_size - RepetitiveLength] = img[0: window_size - RepetitiveLength,
                                                                               0: window_size - RepetitiveLength]
            #  最后一行的要再特殊考虑，下边的边缘要考虑进去
            elif (j == len(TifArray) - 1):
                #  原来错误的
                # result[shape[0] - ColumnOver : shape[0], 0 : 512 - RepetitiveLength] = img[0 : ColumnOver, 0 : 512 - RepetitiveLength]
                #  后来修改的
                result[shape[0] - ColumnOver - RepetitiveLength: shape[0], 0: window_size - RepetitiveLength] = img[
                                                                                                        window_size - ColumnOver - RepetitiveLength: window_size,
                                                                                                        0: window_size - RepetitiveLength]
            else:
                result[j * (window_size - 2 * RepetitiveLength) + RepetitiveLength: (j + 1) * (
                            window_size - 2 * RepetitiveLength) + RepetitiveLength,
                0:window_size - RepetitiveLength] = img[RepetitiveLength: window_size - RepetitiveLength, 0: window_size - RepetitiveLength]
                #  最右侧一列特殊考虑，右边的边缘要拼接进去
        elif (i % len(TifArray[0]) == len(TifArray[0]) - 1):
            #  第一行的要再特殊考虑，上边的边缘要考虑进去
            if (j == 0):
                result[0: window_size - RepetitiveLength, shape[1] - RowOver: shape[1]] = img[0: window_size - RepetitiveLength,
                                                                                  window_size - RowOver: window_size]
            #  最后一行的要再特殊考虑，下边的边缘要考虑进去
            elif (j == len(TifArray) - 1):
                result[shape[0] - ColumnOver: shape[0], shape[1] - RowOver: shape[1]] = img[window_size - ColumnOver: window_size,
                                                                                        window_size - RowOver: window_size]
            else:
                result[j * (window_size - 2 * RepetitiveLength) + RepetitiveLength: (j + 1) * (
                            window_size - 2 * RepetitiveLength) + RepetitiveLength,
                shape[1] - RowOver: shape[1]] = img[RepetitiveLength: window_size - RepetitiveLength, window_size - RowOver: window_size]
                #  走完每一行的最右侧，行数+1
            j = j + 1
        #  不是最左侧也不是最右侧的情况
        else:
            #  第一行的要特殊考虑，上边的边缘要考虑进去
            if (j == 0):
                result[0: window_size - RepetitiveLength,
                (i - j * len(TifArray[0])) * (window_size - 2 * RepetitiveLength) + RepetitiveLength: (i - j * len(
                    TifArray[0]) + 1) * (window_size - 2 * RepetitiveLength) + RepetitiveLength
                ] = img[0: window_size - RepetitiveLength, RepetitiveLength: window_size - RepetitiveLength]
                #  最后一行的要特殊考虑，下边的边缘要考虑进去
            if (j == len(TifArray) - 1):
                result[shape[0] - ColumnOver: shape[0],
                (i - j * len(TifArray[0])) * (window_size - 2 * RepetitiveLength) + RepetitiveLength: (i - j * len(
                    TifArray[0]) + 1) * (window_size - 2 * RepetitiveLength) + RepetitiveLength
                ] = img[window_size - ColumnOver: window_size, RepetitiveLength: window_size - RepetitiveLength]
            else:
                result[j * (window_size - 2 * RepetitiveLength) + RepetitiveLength: (j + 1) * (
                            window_size - 2 * RepetitiveLength) + RepetitiveLength,
                (i - j * len(TifArray[0])) * (window_size - 2 * RepetitiveLength) + RepetitiveLength: (i - j * len(
                    TifArray[0]) + 1) * (window_size - 2 * RepetitiveLength) + RepetitiveLength,
                ] = img[RepetitiveLength: window_size - RepetitiveLength, RepetitiveLength: window_size - RepetitiveLength]
    return result


area_perc = 0.5  #default 0.5  ,not overlape:1
RepetitiveLength = int((1 - math.sqrt(area_perc)) * window_size / 2)
DEVICE =torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')


# 将模型加载到指定设备DEVICE上
model = ViT_seg().cuda()
snapshot = os.path.join(args.output_dir, 'epoch_199.pth')
model.load_state_dict(torch.load(snapshot))
model.to(DEVICE)


import glob
big_image_dir = 'F:/SwinUnet/input_large_2015/*.tiff'
result_dir = 'F:/SwinUnet/output_large_unet/2015'
os.makedirs(result_dir,exist_ok=True)
file_list = glob.glob(big_image_dir)
import time
start_time = time.time()
for path in file_list:
    print(path)
    ResultPath = os.path.join(result_dir, path.split('\\')[-1])
    big_image,transform,proj =readTif(path)

    big_image = big_image.swapaxes(1, 0).swapaxes(1, 2)
    TifArray, RowOver, ColumnOver = TifCroppingArray(big_image, RepetitiveLength)

    predicts = []
    for i in range(len(TifArray)):
        for j in range(len(TifArray[0])):
            print("predict:", i, "/", len(TifArray), "-----", j, "/", len((TifArray[0])))
            image = TifArray[i][j] / 1.0
            # image = trfm(image)
            image = torch.from_numpy(image.astype(np.float32))
            image = image.permute(2, 0, 1)
            image = image/3600.0

            ####        resize ?
            # image = image.resize((224,224))
            # ----------------------
            image = image.cuda()
            pred = np.zeros_like((window_size, window_size, 21))  # 512,512,num_classes
            for model_path in snapshot:
                model.load_state_dict(torch.load(snapshot))
                model.eval()
                image = image.float()
                if len(image.shape) == 3:
                    image = image.unsqueeze(0)
                with torch.no_grad():
                    out = torch.argmax(torch.softmax(model(image), dim=1), dim=1).squeeze(0)
                    pred = out.cpu().detach().numpy()

            # pred = pred / (len(snapshot) * 3)
            pred = pred.astype(np.uint8)
            pred = pred.reshape((window_size, window_size))

            predicts.append((pred))

    # 保存结果predicts
    result_shape = (big_image.shape[0], big_image.shape[1])
    print("shape:", result_shape)
    result_data = Result(result_shape, TifArray, predicts, RepetitiveLength, RowOver, ColumnOver)
    writeTiff(ResultPath, result_data,transform,proj)
print("spend time:", time.time()-start_time)



