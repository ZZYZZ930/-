import os
from collections import defaultdict
from PIL import Image

# VOC类别名称及对应的索引
class_names = [
    '0', '1', '2', '3', '4', '5', '6', '7',
    '8', '9', '10', '11', '12', '13', '14', '15',
    '16', '17', '18', '19', '20', '21'
]

# 初始化类别像素计数器
class_pixel_counts = defaultdict(int)

# 数据集路径
dataset_dir = 'F:\\SwinUnet\\img_datas\\train\\label'  # 替换为实际的VOC数据集路径

# 遍历数据集
for image_file in os.listdir(dataset_dir):
    if image_file.endswith('.tif'):  # 仅处理PNG格式的分割标签图像
        image_path = os.path.join(dataset_dir, image_file)
        image = Image.open(image_path)
        pixels = image.load()
        width, height = image.size

        # 统计像素数量
        for y in range(height):
            for x in range(width):
                class_index = pixels[x, y]
                class_pixel_counts[class_index] += 1

# 计算像素占比
total_pixels = sum(class_pixel_counts.values())
class_pixel_ratios = {class_names[class_index]: count / total_pixels for class_index, count in
                      class_pixel_counts.items()}

# 打印结果
for class_name, pixel_ratio in class_pixel_ratios.items():
    print(f'{class_name}: {pixel_ratio * 100:.2f}%')