#python train_swin.py &wait
#python train_unet.py &wait
python inference_large_dir.py &wait
python inference_large_dir_unet.py &wait